<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Espazo
 * @package App\Models
 * @version March 7, 2019, 10:03 am CET
 *
 * @property \Illuminate\Database\Eloquent\Collection Avaliacionmonitor
 * @property string nome
 * @property string enderezo
 * @property string postal
 * @property string localidade
 * @property string mapa
 */
class Espazo extends Model
{
    use SoftDeletes;

    public $table = 'espazos';
    

    protected $dates = ['deleted_at'];


    public $fillable = [
        'nome',
        'enderezo',
        'postal',
        'localidade',
        'mapa'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'nome' => 'string',
        'enderezo' => 'string',
        'postal' => 'string',
        'localidade' => 'string',
        'mapa' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'nome' => 'required',
        'enderezo' => '',
        'postal' => '',
        'localidade' => '',
        'mapa' => 'url|nullable'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     **/
    public function avaliacionmonitors()
    {
        return $this->hasMany(\App\Models\Avaliacionmonitor::class);
    }

    public function actividades()
    {
    return $this->belongsToMany('App\Models\Actividade')->withTimestamps();
    }

}
