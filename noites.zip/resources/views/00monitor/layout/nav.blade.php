<nav>
	<div class="nav-wrapper">
		<a href="{!!url('monitor/home')!!}" class="brand-logo">{!!$monitor->name!!} {!!$monitor->apelido1!!}</a>
		<a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
		{{--
		<ul class="right hide-on-med-and-down">
			<li><a href="{!!url('monitor/avaliacion')!!}">Avaliación persoas usuarias</a></li>
		</ul>
		--}}
	</div>
</nav>

<ul class="sidenav" id="mobile-demo">
		{{--
			<li><a href="{!!url('monitor/avaliacion')!!}">Avaliación persoas usuarias</a></li>
		--}}
</ul>