<!-- Espazo Id Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('coordinador_id', 'Coordinador da actividade:'); ?>

    <select class="form-control select2" name="coordinador_id">
        <?php if(isset($avaliacionmonitors)): ?>
        <?php $__currentLoopData = $coordinadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coordinador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php if($coordinador->id === $avaliacionmonitors->coordinador_id): ?> selected <?php endif; ?> value="<?php echo $coordinador->id; ?>"><?php echo $coordinador->name; ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <option value="" disabled="disabled">-- Selecciona un coordinador --</option>
        <?php $__currentLoopData = $coordinadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coordinador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo $coordinador->id; ?>"><?php echo $coordinador->name; ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<!-- monitors Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('monitors', 'Nome do monitorado:'); ?>

    <?php echo Form::text('monitors', null, ['class' => 'form-control']); ?>

</div>

<!-- monitors Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('data', 'Data:'); ?>

    <?php if(isset($avaliacionmonitors)): ?>
    <?php echo Form::date('data', $avaliacionmonitors->data, ['class' => 'form-control']); ?>

    <?php else: ?>
    <?php echo Form::date('data', null, ['class' => 'form-control']); ?>

    <?php endif; ?>
</div>

<!-- Participantes Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('participantes', 'Participantes:'); ?>

    <?php echo Form::number('participantes', null, ['class' => 'form-control']); ?>

</div>

<!-- Participantes Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('publico', 'Público:'); ?>

    <?php echo Form::number('publico', null, ['class' => 'form-control']); ?>

</div>


<!-- Participantes Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('fora', 'Xente fora:'); ?>

    <?php echo Form::number('fora', null, ['class' => 'form-control']); ?>

</div>

<!-- Primeiravez Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('primeiravez', 'Veñen por vez primeira:'); ?>

    <?php echo Form::number('primeiravez', null, ['class' => 'form-control']); ?>

</div>

<!-- Moza12 Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('moza12', 'Mozas 12-16:'); ?>

    <?php echo Form::number('moza12', null, ['class' => 'form-control']); ?>

</div>

<!-- Moza17 Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('moza17', 'Mozas 17-25:'); ?>

    <?php echo Form::number('moza17', null, ['class' => 'form-control']); ?>

</div>

<!-- moza26 Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('moza26', 'Mozas 26 e +:'); ?>

    <?php echo Form::number('moza26', null, ['class' => 'form-control']); ?>

</div>

<!-- Mozo12 Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('mozo12', 'Mozos 12-16:'); ?>

    <?php echo Form::number('mozo12', null, ['class' => 'form-control']); ?>

</div>

<!-- Mozo17 Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('mozo17', 'Mozos 17-25:'); ?>

    <?php echo Form::number('mozo17', null, ['class' => 'form-control']); ?>

</div>

<!-- mozo26 Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('mozo26', 'Mozos 26 e +:'); ?>

    <?php echo Form::number('mozo26', null, ['class' => 'form-control']); ?>

</div>

<!-- Valoracionespazo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('valoracionespazo', 'Valoracion Espazo:'); ?>

    <?php echo Form::number('valoracionespazo', null, ['class' => 'form-control', 'step'=>1, 'min'=>1, 'max'=>5]); ?>

</div>

<!-- Valoracionmateriais Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('valoracionmateriais', 'Valoracion Materiais:'); ?>

    <?php echo Form::number('valoracionmateriais', null, ['class' => 'form-control', 'step'=>1, 'min'=>1, 'max'=>5]); ?>

</div>

<!-- Valoracionhorario Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('valoracionhorario', 'Valoracion Horario:'); ?>

    <?php echo Form::number('valoracionhorario', null, ['class' => 'form-control', 'step'=>1, 'min'=>1, 'max'=>5]); ?>

</div>

<!-- Valoracionparticipacion Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('valoracionparticipacion', 'Valoracion Participacion:'); ?>

    <?php echo Form::number('valoracionparticipacion', null, ['class' => 'form-control', 'step'=>1, 'min'=>1, 'max'=>5]); ?>

</div>

<!-- Valoracionxeral Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('valoracionxeral', 'Valoracion Xeral:'); ?>

    <?php echo Form::number('valoracionxeral', null, ['class' => 'form-control', 'step'=>1, 'min'=>1, 'max'=>5]); ?>

</div>

<!-- Control Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('control', 'Labor de control:'); ?>

    <?php echo Form::number('control', null, ['class' => 'form-control', 'step'=>1, 'min'=>1, 'max'=>5]); ?>

</div>

<!-- Obsevacions Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('obsevacions', 'Obsevacions:'); ?>

    <?php echo Form::textarea('obsevacions', null, ['class' => 'form-control']); ?>

</div>

<!-- Espazo Id Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('actividade_id', 'Actividade a que corresponde a avaliación:'); ?>

    <select class="form-control select2" name="actividade_id">
        <?php if(isset($avaliacionmonitors)): ?>
        <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php if($actividade->id === $avaliacionmonitors->actividade_id): ?> selected <?php endif; ?> value="<?php echo $actividade->id; ?>"><?php echo $actividade->nome; ?> (Edición <?php echo $actividade->edicion; ?>, ano <?php echo $actividade->ano; ?>)</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <option value="" disabled="disabled">-- Selecciona unha actividade --</option>
        <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo $actividade->id; ?>"><?php echo $actividade->nome; ?> (Edición <?php echo $actividade->edicion; ?>, ano <?php echo $actividade->ano; ?>)</option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<!-- Espazo Id Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('espazo_id', 'Espazo onde se celebra a actividade:'); ?>

    <select class="form-control select2" name="espazo_id">
        <?php if(isset($avaliacionmonitors)): ?>
        <?php $__currentLoopData = $espazos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $espazo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php if($espazo->id === $avaliacionmonitors->espazo_id): ?> selected <?php endif; ?> value="<?php echo $espazo->id; ?>"><?php echo $espazo->nome; ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <option value="" disabled="disabled">-- Selecciona un espazo --</option>
        <?php $__currentLoopData = $espazos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $espazo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo $espazo->id; ?>"><?php echo $espazo->nome; ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('avaliacionmonitors.index'); ?>" class="btn btn-default">Cancel</a>
</div>
