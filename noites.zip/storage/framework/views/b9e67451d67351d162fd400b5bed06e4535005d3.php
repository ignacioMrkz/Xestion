<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $monitor->id; ?></p>
</div>

<!-- Nome Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Nome:'); ?>

    <p><?php echo $monitor->name; ?></p>
</div>
<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $monitor->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $monitor->updated_at; ?></p>
</div>

