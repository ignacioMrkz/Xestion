<!-- Inicio Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('inicio', 'Inicio:'); ?>

    <?php echo Form::date('inicio', null, ['class' => 'form-control']); ?>

</div>

<!-- Inicio Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('hora_inicio', 'Hora de inicio:'); ?>

    <?php echo Form::time('hora_inicio', null, ['class' => 'form-control']); ?>

</div>

<!-- Fin Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('fin', 'Fin:'); ?>

    <?php echo Form::date('fin', null, ['class' => 'form-control']); ?>

</div>

<!-- Fin Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('hora_fin', 'Hora fin:'); ?>

    <?php echo Form::time('hora_fin', null, ['class' => 'form-control']); ?>

</div>

<!-- Actividade Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('actividade_id', 'Actividade:'); ?>

    <?php echo Form::select('actividade_id', $actividades, null, ['class' => 'form-control select2', 'placeholder' => '-- Escolle unha actividade --']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('eventos.index'); ?>" class="btn btn-default">Cancel</a>
</div>
