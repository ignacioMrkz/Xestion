<?php $__env->startSection('content'); ?>
<?php echo $__env->make('coordinador.layout.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
    <?php if($coordinador->pendienteRevisar()): ?>
<table class="highlight centered centered-table">
    <thead>
        <tr>
            <th>Actividade</th>
            <th>Data</th>
            <th>Accions</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $avaliacions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avaliacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($avaliacion->actividade->nome); ?></td>
            <td><?php echo e($avaliacion->data->format('d-m-Y')); ?></td>
            <td>
                <a href="<?php echo url('coordinador/revisar-avaliacion/'.$avaliacion->id); ?>" class="waves-effect waves-light orange btn"><i class="material-icons right">rate_review</i>Revisar</a>
                <a href="<?php echo url('coordinador/validar-avaliacion/'.$avaliacion->id); ?>" class="waves-effect waves-light btn"><i class="material-icons right">check</i>Validar</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
<h5 class="center-align">Non tes avaliacións que revisar</h5>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    <?php if($coordinador->pendienteRevisar()): ?>
    $(document).ready(function(){
        $('.modal').modal();
        $('#modal-pendientes').modal('open');
    });
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>