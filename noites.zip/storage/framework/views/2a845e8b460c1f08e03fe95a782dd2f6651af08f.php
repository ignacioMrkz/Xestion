<!-- Xenero Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('xenero', 'Xenero:'); ?>


</div>

<!-- Puntuacion Monitores Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('monitores', 'Puntuacion Monitores:'); ?>


</div>

<!-- Puntuacionespazo Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('espazo', 'Puntuacionespazo:'); ?>


</div>

<!-- Puntuacion Materiais Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('materiais', 'Puntuacion Materiais:'); ?>


</div>

<!-- Puntuacion Horario Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('horario', 'Puntuacion Horario:'); ?>


</div>

<!-- Valoracion Xeral Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('xeral', 'Valoracion Xeral:'); ?>


</div>

<!-- Falta Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('falta', 'Falta:'); ?>

    <?php echo Form::textarea('falta', null, ['class' => 'form-control']); ?>

</div>

<!-- Suxerencias Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('suxerencias', 'Suxerencias:'); ?>

    <?php echo Form::textarea('suxerencias', null, ['class' => 'form-control']); ?>

</div>

<!-- Actividade Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('actividade_id', 'Actividade Id:'); ?>

    <?php echo Form::number('actividade_id', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('avaliacionsatisfacions.index'); ?>" class="btn btn-default">Cancel</a>
</div>
