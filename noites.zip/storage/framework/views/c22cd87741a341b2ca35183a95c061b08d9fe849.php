<!-- Nome Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nome', 'Nome:'); ?>

    <?php echo Form::text('nome', null, ['class' => 'form-control']); ?>

</div>

<!-- Enderezo Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('enderezo', 'Enderezo:'); ?>

    <?php echo Form::text('enderezo', null, ['class' => 'form-control']); ?>

</div>

<!-- Postal Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('postal', 'Código postal:'); ?>

    <?php echo Form::text('postal', null, ['class' => 'form-control']); ?>

</div>

<!-- Localidade Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('localidade', 'Localidade:'); ?>

    <?php echo Form::select('localidade', pontevedra(), null, ['class' => 'form-control', 'placeholder'=>'--Escolle unha cidade--']); ?>

</div>

<!-- Mapa Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('mapa', 'Mapa:'); ?>

    <?php echo Form::text('mapa', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('espazos.index'); ?>" class="btn btn-default">Cancel</a>
</div>
