<table class="table table-responsive" id="avaliacionsatisfacions-table">
    <thead>
        <tr>
            <th>Actividade</th>
            <th>Edición</th>
            <th>Ano</th>
            <th>Data</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $avaliacionsatisfacions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avaliacionsatisfacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $avaliacionsatisfacion->actividade->nome; ?></td>
            <td><?php echo $avaliacionsatisfacion->actividade->edicion; ?></td>
            <td><?php echo $avaliacionsatisfacion->actividade->ano; ?></td>
            <td><?php echo $avaliacionsatisfacion->created_at->format('d-m-Y'); ?></td>
            <td>
                <?php echo Form::open(['route' => ['avaliacionsatisfacions.destroy', $avaliacionsatisfacion->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('avaliacionsatisfacions.show', [$avaliacionsatisfacion->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('avaliacionsatisfacions.edit', [$avaliacionsatisfacion->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Estás seguro?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $('#avaliacionsatisfacions-table').DataTable();
</script>
<?php $__env->stopSection(); ?>