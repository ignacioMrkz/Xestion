<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $coordinador->id; ?></p>
</div>

<!-- Nome Field -->
<div class="form-group">
    <?php echo Form::label('name', 'Nome:'); ?>

    <p><?php echo $coordinador->name; ?></p>
</div>
<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $coordinador->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $coordinador->updated_at; ?></p>
</div>

