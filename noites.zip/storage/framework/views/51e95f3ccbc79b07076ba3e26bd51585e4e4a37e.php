<!-- Nome Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nome', 'Nome:'); ?>

    <?php echo Form::text('nome', null, ['class' => 'form-control']); ?>

</div>

<!-- Capacidade Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('capacidade', 'Capacidade:'); ?>

    <?php echo Form::number('capacidade', null, ['class' => 'form-control']); ?>

</div>

<!-- Data Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('data', 'Data:'); ?>

    <?php echo Form::date('data', null, ['class' => 'form-control']); ?>

</div>

<!-- Horario Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('horario', 'Horario:'); ?>

    <?php echo Form::text('horario', null, ['class' => 'form-control']); ?>

</div>

<!-- Materiais Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('materiais', 'Materiais:'); ?>

    <?php echo Form::textarea('materiais', null, ['class' => 'form-control']); ?>

</div>

<!-- Empresa Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('empresa', 'Empresa:'); ?>

    <?php echo Form::text('empresa', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('actividades.index'); ?>" class="btn btn-default">Cancel</a>
</div>
