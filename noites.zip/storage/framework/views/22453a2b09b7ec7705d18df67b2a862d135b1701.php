<?php $__env->startSection('content'); ?>
<?php echo $__env->make('monitor.layout.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
	<div class="row">
		<?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col s12 m6">
			<div class="card">
				<div class="card-content">
					<h5><?php echo e($actividade->nome); ?></h5>
					<a class="btn waves-effect waves-light red" href="<?php echo 'avaliacion/'.$actividade->id; ?>">Avaliación</a>
					<hr>
					<?php $__currentLoopData = $actividade->espazos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $espazo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="row">
						<div class="col s12">
							<?php if($espazo->mapa): ?>
	  						<a class="btn-floating waves-effect waves-light red right" href="<?php echo $espazo->mapa; ?>" target="_blank"><i class="material-icons">place</i></a>
	  						<?php endif; ?>
							<p><?php echo $espazo->nome; ?></p>
						</div>
					</div>
  					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>