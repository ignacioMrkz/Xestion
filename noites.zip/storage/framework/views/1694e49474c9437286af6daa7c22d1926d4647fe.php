<!-- Nome Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nome', 'Nome:'); ?>

    <?php echo Form::text('nome', null, ['class' => 'form-control']); ?>

</div>

<!-- Capacidade Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('capacidade', 'Capacidade:'); ?>

    <?php echo Form::number('capacidade', null, ['class' => 'form-control']); ?>

</div>

<!-- Data Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('data', 'Data:'); ?>

    <?php if(isset($actividade)): ?>
    <?php echo Form::date('data', $actividade->data, ['class' => 'form-control']); ?>

    <?php else: ?>
    <?php echo Form::date('data', null, ['class' => 'form-control']); ?>

    <?php endif; ?>
</div>

<!-- Horario Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('horario', 'Horario:'); ?>

    <?php echo Form::text('horario', null, ['class' => 'form-control']); ?>

</div>

<!-- Materiais Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('materiais', 'Materiais:'); ?>

    <?php echo Form::textarea('materiais', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group col-sm-12">
    <?php echo Form::label('espazos[]', 'Espazos onde se celebra a actividade:'); ?>

    <select class="form-control select2" name="espazos[]" multiple="multiple">
        <?php if(isset($actividade)): ?>
        <?php $__currentLoopData = $espazos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $espazo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option <?php if(in_array($espazo->id, $actividade->espazos->pluck('id')->toArray())): ?> selected <?php endif; ?> value="<?php echo $espazo->id; ?>"><?php echo $espazo->nome; ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <?php $__currentLoopData = $espazos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $espazo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo $espazo->id; ?>"><?php echo $espazo->nome; ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </select>
</div>

<!-- Empresa Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('empresa', 'Empresa:'); ?>

    <?php echo Form::text('empresa', null, ['class' => 'form-control']); ?>

</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('actividades.index'); ?>" class="btn btn-default">Cancel</a>
</div>
