<h5><b>Actividade:</b> <?php echo $avaliacionmonitors->actividade->nome; ?></h5>
<h5><b>Data:</b> <?php echo date_format($avaliacionmonitors->data, 'd-m-Y'); ?></h5>
<h5><b>Espazo:</b> <?php echo $avaliacionmonitors->espazo->nome; ?></h5>
<h5><b>Realizado por:</b> <?php echo $avaliacionmonitors->coordinador->name; ?> <?php echo $avaliacionmonitors->coordinador->apellido1; ?> <?php echo $avaliacionmonitors->coordinador->apellido2; ?></h5>
<h5><b>Estado:</b> <?php if($avaliacionmonitors->revisada): ?>Revisada <?php else: ?> Pendiente de revisar <?php endif; ?></h5>
<div class="col-md-6">
<div class="box box-danger">
    <div class="box-header with-border">
        <h3 class="box-title">Valoracións</h3>

        <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
    </div>
    <div class="box-body">
        <canvas id="valoracion" style="height: 228px; width: 457px;" width="914" height="456"></canvas>
    </div>
</div>
</div>
<div class="col-md-6">
<div class="box box-warning">
    <div class="box-header with-border">
        <h3 class="box-title">Novos usuarios</h3>

        <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
    </div>
    <div class="box-body">
        <canvas id="novos" style="height: 228px; width: 457px;" width="914" height="456"></canvas>
    </div>
</div>
</div>
<div class="col-md-6">
<div class="box box-primary">
    <div class="box-header with-border">
        <h3 class="box-title">Idade usuarios</h3>

        <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
    </div>
    <div class="box-body">
        <canvas id="idade" style="height: 228px; width: 457px;" width="914" height="456"></canvas>
    </div>
</div>
</div>
<div class="col-md-6">
<div class="box box-success">
    <div class="box-header with-border">
        <h3 class="box-title">Datos xerais</h3>

        <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
        </div>
    </div>
    <div class="box-body">
        <p><b>Público:</b> <?php echo $avaliacionmonitors->publico; ?></p>
        <p><b>Xente fora:</b> <?php echo $avaliacionmonitors->fora; ?></p>
        <p><b>Nome do espazo:</b> <?php echo $avaliacionmonitors->espazo->nome; ?></p>
        <p><b>Data:</b> <?php echo date_format($avaliacionmonitors->data, 'd-m-Y'); ?></p>
        <p><b>Suxerencias:</b> <?php echo $avaliacionmonitors->obsevacions; ?></p>
    </div>
</div>
</div>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
var ctx = $('#valoracion');
var myRadarChart = new Chart(ctx, {
    type: 'radar',
    data: {
        labels: ['Espazo', 'Materiais', 'Horario', 'Participación', 'Xeral', 'Labor de control'],
        datasets: [{
            label: 'Valoracions',
            data: [<?php echo $avaliacionmonitors->valoracionespazo; ?>, <?php echo $avaliacionmonitors->valoracionmateriais; ?>, <?php echo $avaliacionmonitors->valoracionhorario; ?>, <?php echo $avaliacionmonitors->valoracionparticipacion; ?>, <?php echo $avaliacionmonitors->valoracionxeral; ?>, <?php echo $avaliacionmonitors->control; ?>],
            backgroundColor: '#00a65a66',
            borderColor: '#00a65a',
        }],
    },
    options: {
        scale: {
            ticks: {
                beginAtZero: true,
                max: 5,
                min: 0,
                stepSize: 1
            }
        }
    }
});
var ctx2 = $('#novos');
var novosChart = new Chart(ctx2, {
    type: 'doughnut',
    data: {
        datasets: [{
            data: [<?php echo $avaliacionmonitors->primeiravez; ?>, <?php echo $avaliacionmonitors->participantes - $avaliacionmonitors->primeiravez; ?>],
            backgroundColor: ['#00a65a', '#dd4b39'],
        }],
        labels: ['Novos (<?php echo $avaliacionmonitors->primeiravez; ?>)', 'Recurrentes (<?php echo $avaliacionmonitors->participantes - $avaliacionmonitors->primeiravez; ?>)'],
    }
});
var ctx3 = $('#idade');
var idadeChart = new Chart(ctx3, {
    type: 'doughnut',
    data: {
        datasets: [{
            data: [<?php echo $avaliacionmonitors->moza12; ?>, <?php echo $avaliacionmonitors->moza17; ?>, <?php echo $avaliacionmonitors->moza26; ?>, <?php echo $avaliacionmonitors->mozo12; ?>, <?php echo $avaliacionmonitors->mozo17; ?>, <?php echo $avaliacionmonitors->mozo26; ?>],
            backgroundColor: ['#fff176', '#ffb74d', '#f06292', '#4db6ac', '#4fc3f7', '#9575cd'],
        }],
        labels: ['Mozas 12-16 (<?php echo $avaliacionmonitors->moza12; ?>)', 'Mozas 17-25 (<?php echo $avaliacionmonitors->moza17; ?>)', 'Mozas 26 e + (<?php echo $avaliacionmonitors->moza26; ?>)', 'Mozos 12-16 (<?php echo $avaliacionmonitors->mozo12; ?>)', 'Mozos 17-25 (<?php echo $avaliacionmonitors->mozo17; ?>)', 'Mozos 26 e + (<?php echo $avaliacionmonitors->mozo26; ?>)'],
    }
});
</script>
<?php $__env->stopSection(); ?>