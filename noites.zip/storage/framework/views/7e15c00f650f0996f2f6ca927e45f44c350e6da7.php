<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    	<?php $__currentLoopData = $edicions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	<a href="<?php echo url('datos/'.$edicion); ?>" class="btn bg-maroon btn-flat margin">Edición <?php echo $edicion; ?></a>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>