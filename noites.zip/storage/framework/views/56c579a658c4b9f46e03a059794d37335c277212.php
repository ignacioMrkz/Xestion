<!-- Nome Field -->
<div class="form-group col-sm-12 col-md-4">
    <?php echo Form::label('name', 'Nome:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Enderezo Field -->
<div class="form-group col-sm-12 col-md-4">
    <?php echo Form::label('email', 'E-mail:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

</div>
<?php if(!isset($administrador)): ?>
<!-- Postal Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('password', 'Contrasinal:'); ?>

    <?php echo Form::password('password', ['class' => 'form-control']); ?>

</div>

<!-- Postal Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('password-confirm', 'Confirma contrasinal:'); ?>

    <?php echo Form::password('password_confirmation', ['class' => 'form-control']); ?>

</div>
<?php endif; ?>
<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('administradors.index'); ?>" class="btn btn-default">Cancel</a>
</div>
