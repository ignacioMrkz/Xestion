<table class="table table-responsive" id="actividades-table">
    <thead>
        <tr>
            <th>Nome</th>
        <th>Capacidade</th>
        <th>Data</th>
        <th>Horario</th>
        <th>Materiais</th>
        <th>Empresa</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $actividade->nome; ?></td>
            <td><?php echo $actividade->capacidade; ?></td>
            <td><?php echo $actividade->data; ?></td>
            <td><?php echo $actividade->horario; ?></td>
            <td><?php echo $actividade->materiais; ?></td>
            <td><?php echo $actividade->empresa; ?></td>
            <td>
                <?php echo Form::open(['route' => ['actividades.destroy', $actividade->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('actividades.show', [$actividade->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('actividades.edit', [$actividade->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>