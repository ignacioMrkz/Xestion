<table class="table table-responsive" id="eventos-table">
    <thead>
        <tr>
            <th>Inicio</th>
        <th>Fin</th>
        <th>Actividade</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $evento->inicio; ?></td>
            <td><?php echo $evento->fin; ?></td>
            <td><?php echo $evento->actividade->nome; ?></td>
            <td>
                <?php echo Form::open(['route' => ['eventos.destroy', $evento->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('eventos.show', [$evento->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('eventos.edit', [$evento->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Estás seguro?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>