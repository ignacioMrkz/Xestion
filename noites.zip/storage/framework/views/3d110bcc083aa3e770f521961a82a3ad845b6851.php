<?php $__env->startSection('content'); ?>
<?php echo $__env->make('coordinador.layout.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php if(isset($mensajeActualizar)): ?>
<div class="row">
    <div class="alert alert-danger">
        <ul>
            <div class="card-panel teal lighten-2 white-text">
                Persoa socia actualizada correctamente
            </div>
        </ul>
    </div>
</div>
<?php elseif(isset($mensajeBorrar)): ?>
<div class="row">
    <div class="alert alert-danger">
        <ul>
            <div class="card-panel red lighten-2 white-text">
                Persoa socia eliminada correctamente
            </div>
        </ul>
    </div>
</div>
<?php endif; ?>
<div class="row">
    <div class="col s12 m6">
        <div class="search">
          <div class="search-wrapper">
            <input id="search" placeholder="Buscador">
            <div class="search-results"></div>
        </div>
    </div>
</div>
<div class="row">
<table class="highlight centered centered-table">
    <thead>
        <tr>
            <th>Número</th>
            <th>Nome</th>
            <th>Accións</th>
            
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $socios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="socio">
            <td class="numero-socio"><?php echo e($socio->numero); ?></td>
            <td class="nome-socio"><?php echo e($socio->nome); ?></td>
            <td>
                <a href="<?php echo url('coordinador/editar-socio/'.$socio->id); ?>" class="waves-effect waves-light orange btn-small"><i class="material-icons">edit</i></a>
                <a href="<?php echo url('coordinador/eliminar-socio/'.$socio->id); ?>" class="waves-effect waves-light red btn-small" onclick="return confirm('Eliminarás esta persoa socia, estás seguro?')"><i class="material-icons">delete</i></a>
            </td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $('#search').on('input', function() {
            var value = $(this).val();
            if (value.length > 3) {
                $('.socio').each(function(index, el) {
                    if ($(this).find('.nome-socio').html().toUpperCase().includes(value.toUpperCase()) || $(this).find('.numero-socio').html().toUpperCase().includes(value.toUpperCase())) {
                        $(this).show('400');
                    } else {
                        $(this).hide('400');
                    }
                });
            } else {
                $('.socio').show('400');
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>