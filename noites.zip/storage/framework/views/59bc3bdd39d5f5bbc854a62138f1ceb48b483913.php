<?php $__env->startSection('content'); ?>
<div class="container">
	<h4>Avaliación monitors</h4>
	<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<ul>
			<div class="card-panel red white-text darken-2">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($error); ?><br>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</ul>
	</div>
	<?php endif; ?>
	<?php echo Form::open(['url'=>'coordinador/avaliacion-monitors']); ?>

	<div class="row">
		<div class="input-field col s12">
			<div class="input-field col s12">
				<h5>Actividade: <?php echo e($actividade->nome); ?></h5>
				<?php echo Form::hidden('actividade_id', $actividade->id); ?>

			</div>
		</div>
	</div>
	<div class="row">
		<h5>Nome do monitorado:</h5>
		<p>
			<label>
				<input type="text" name="monitors" value="<?php echo e(old('monitors')); ?>">
			</label>
		</p>
	</div>
	<div class="row">
		<h5>Espazo:</h5>
		<select name="espazo_id">
			<option value="" disabled selected="selected">Escolle un espazo</option>
			<?php $__currentLoopData = $espazos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $espazo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo $espazo->id; ?>" <?php echo e(old('espazo_id') == $espazo->id ? ' selected' : ''); ?>><?php echo $espazo->nome; ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
	</div>
	<div class="row">
		<div class="input-field col s12">
			<h5>Data:</h5>
			<p>
				<label>
					<input type="text" class="datepicker" name="data">
				</label>
			</p>
		</div>
	</div>
	<div class="row">
		<div class="input-field col s12 m6">
			<h5>Total persoas participantes:</h5>
			<p>
				<label>
					<input type="number" name="participantes" value="<?php echo e(old('participantes')); ?>">
				</label>
			</p>
		</div>
		<div class="input-field col s12 m6">
			<h5>Cántas persoas veñen por vez primeira a Noites este ano?:</h5>
			<p>
				<label>
					<input type="number" name="primeiravez" value="<?php echo e(old('primeiravez')); ?>">
				</label>
			</p>
		</div>
	</div>
	<div class="row">
		<h5>Anota as persoas participantes:</h5>
		<table class="center-align" id="participantes-table">
			<thead>
				<tr>
					<th></th>
					<th class="center-align">Mozos</th>
					<th class="center-align">Mozas</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>12-16</td>
					<td>
						<label>
							<input type="number" name="mozo12" value="<?php echo e(old('mozo12')); ?>" class="center-align" min="0" step="1" />
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="number" name="moza12" value="<?php echo e(old('moza12')); ?>" class="center-align" min="0" step="1" />
							<span></span>
						</label>
					</td>
				</tr>
				<tr>
					<td>17-25</td>
					<td>
						<label>
							<input type="number" name="mozo17" value="<?php echo e(old('mozo17')); ?>" class="center-align" min="0" step="1" />
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="number" name="moza17" value="<?php echo e(old('moza17')); ?>" class="center-align" min="0" step="1" />
							<span></span>
						</label>
					</td>
				</tr>
				<tr>
					<td>26 e +</td>
					<td>
						<label>
							<input type="number" name="mozo26" value="<?php echo e(old('mozo26')); ?>" class="center-align" min="0" step="1" />
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="number" name="moza26" value="<?php echo e(old('moza26')); ?>" class="center-align" min="0" step="1" />
							<span></span>
						</label>
					</td>
				</tr>
			</tbody>
			<tfoot>
				<tr>
					<td>TOTAIS</td>
					<td id="total-mozos" class="center-align">0</td>
					<td id="total-mozas" class="center-align">0</td>
				</tr>
			</tfoot>
		</table>
	</div>
	<div class="row">
		<h5>Avalía os seguintes apartados da actividade:</h5>
		<table class="center-align">
			<thead>
				<tr>
					<th></th>
					<th>1</th>
					<th>2</th>
					<th>3</th>
					<th>4</th>
					<th>5</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>Espazo</td>
					<td>
						<label>
							<input type="radio" name="valoracionespazo" value="1" <?php echo e(old('valoracionespazo') === '1' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionespazo" value="2" <?php echo e(old('valoracionespazo') === '2' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionespazo" value="3" <?php echo e(old('valoracionespazo') === '3' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionespazo" value="4" <?php echo e(old('valoracionespazo') === '4' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionespazo" value="5" <?php echo e(old('valoracionespazo') === '5' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
				</tr>
				<tr>
					<td>Materiais</td>
					<td>
						<label>
							<input type="radio" name="valoracionmateriais" value="1" <?php echo e(old('valoracionmateriais') === '1' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionmateriais" value="2" <?php echo e(old('valoracionmateriais') === '2' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionmateriais" value="3" <?php echo e(old('valoracionmateriais') === '3' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionmateriais" value="4" <?php echo e(old('valoracionmateriais') === '4' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionmateriais" value="5" <?php echo e(old('valoracionmateriais') === '5' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
				</tr>
				<tr>
					<td>Horario</td>
					<td>
						<label>
							<input type="radio" name="valoracionhorario" value="1" <?php echo e(old('valoracionhorario') === '1' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionhorario" value="2" <?php echo e(old('valoracionhorario') === '2' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionhorario" value="3" <?php echo e(old('valoracionhorario') === '3' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionhorario" value="4" <?php echo e(old('valoracionhorario') === '4' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionhorario" value="5" <?php echo e(old('valoracionhorario') === '5' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
				</tr>
				<tr>
					<td>Participación</td>
					<td>
						<label>
							<input type="radio" name="valoracionparticipacion" value="1"<?php echo e(old('valoracionparticipacion') === '1' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionparticipacion" value="2"<?php echo e(old('valoracionparticipacion') === '2' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionparticipacion" value="3"<?php echo e(old('valoracionparticipacion') === '3' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionparticipacion" value="4"<?php echo e(old('valoracionparticipacion') === '4' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionparticipacion" value="5"<?php echo e(old('valoracionparticipacion') === '5' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
				</tr>
				<tr>
					<td>Valoración xeral</td>
					<td>
						<label>
							<input type="radio" name="valoracionxeral" value="1" <?php echo e(old('valoracionxeral') === '1' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionxeral" value="2" <?php echo e(old('valoracionxeral') === '2' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionxeral" value="3" <?php echo e(old('valoracionxeral') === '3' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionxeral" value="4" <?php echo e(old('valoracionxeral') === '4' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="valoracionxeral" value="5" <?php echo e(old('valoracionxeral') === '5' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
				</tr>
				<tr>
					<td>Labor de control</td>
					<td>
						<label>
							<input type="radio" name="control" value="1" <?php echo e(old('control') === '1' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="control" value="2" <?php echo e(old('control') === '2' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="control" value="3" <?php echo e(old('control') === '3' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="control" value="4" <?php echo e(old('control') === '4' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
					<td>
						<label>
							<input type="radio" name="control" value="5" <?php echo e(old('control') === '5' ? ' checked' : ''); ?>/>
							<span></span>
						</label>
					</td>
				</tr>
			</tbody>
		</table>
		<p><b>1</b>: moi mal; <b>2</b>: mal; <b>3</b>: regular; <b>4</b>: ben; <b>5</b>: moi ben</p>
	</div>
	<div class="row">
		<div class="input-field col s12">
			<textarea id="obsevacions" class="materialize-textarea" name="obsevacions"><?php echo e(old('obsevacions')); ?></textarea>
			<label for="obsevacions">Observacións, suxestións de mellora, comentario:</label>
		</div>
	</div>
	<div class="row">
		<div class="input-field col s12">
			<button class="btn waves-effect waves-light" type="submit">Gardar
				<i class="material-icons right">send</i>
			</button>
		</div>
	</div>
	<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#total-mozos').html((parseInt($('input[name="mozo12"]').val()) || 0) + (parseInt($('input[name="mozo17"]').val()) || 0) + (parseInt($('input[name="mozo26"]').val()) || 0));
		$('#total-mozas').html((parseInt($('input[name="moza12"]').val()) || 0) + (parseInt($('input[name="moza17"]').val()) || 0) + (parseInt($('input[name="moza26"]').val()) || 0));
		$('select').formSelect();
		$('.datepicker').datepicker({
			i18n: {
				months: ["Xaneiro", "Febreio", "Marzo", "Abril", "Maio", "Xuño", "Xullo", "Agosto", "Setembro", "Outubro", "Novembro", "Decembro"],
				monthsShort: ["Xan", "Feb", "Mar", "Abr", "Mai", "Xun", "Xul", "Ago", "Set", "Out", "Nov", "Dec"],
				weekdays: ["Domingo","Luns", "Martes", "Mércores", "Xoves", "Venres", "Sábado"],
				weekdaysShort: ["Dom","Lun", "Mar", "Mer", "Xov", "Ven", "Sab"],
				weekdaysAbbrev: ["D","L", "M", "M", "X", "V", "S"]
			},
			format: 'dd/mm/yy',
			defaultDate: new Date(),
			setDefaultDate: true,
		});
	});
	$('#participantes-table').find('input').on('change', function(event) {
		$('#total-mozos').html((parseInt($('input[name="mozo12"]').val()) || 0) + (parseInt($('input[name="mozo17"]').val()) || 0) + (parseInt($('input[name="mozo26"]').val()) || 0));
		$('#total-mozas').html((parseInt($('input[name="moza12"]').val()) || 0) + (parseInt($('input[name="moza17"]').val()) || 0) + (parseInt($('input[name="moza26"]').val()) || 0));
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>