<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row">
    	<?php $__currentLoopData = $edicions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	<a href="<?php echo url('datos-actividades/'.$edicion); ?>" class="btn bg-maroon btn-flat margin">Edición <?php echo $edicion; ?> actividades</a>
    	<a href="<?php echo url('datos-monitors/'.$edicion); ?>" class="btn bg-maroon btn-flat margin">Edición <?php echo $edicion; ?> avaliacións monitors</a>
    	<a href="<?php echo url('datos-satisfaccion/'.$edicion); ?>" class="btn bg-maroon btn-flat margin">Edición <?php echo $edicion; ?> avaliacións satisfacción</a>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div class="row">
		<div class="col-md-12">
			<div class="box box-success box-solid">
				<div class="box-header with-border">
					<h3 class="box-title">Avaliacións con observacions:</h3>
					<div class="box-tools pull-right">
						<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
						</button>
					</div>
				</div>
				<div class="box-body">
					<table class="table table-responsive" id="actividades-table">
						<thead>
							<tr>
								<th>Actividade</th>
								<th>Data</th>
								<th>Suxerencia</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $avaliacions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avaliacionmonitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo $avaliacionmonitor->actividade->nome; ?></td>
            					<td><?php echo date_format($avaliacionmonitor->data, 'Y-m-d'); ?></td>
								<td style="font-size: 10px"><?php echo $avaliacionmonitor->obsevacions; ?></td>
								<td>
					                <?php echo Form::open(['route' => ['avaliacionmonitors.destroy', $avaliacionmonitor->id], 'method' => 'delete']); ?>

					                <div class='btn-group'>
					                    <a href="<?php echo route('avaliacionmonitors.show', [$avaliacionmonitor->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
					                    <a href="<?php echo route('avaliacionmonitors.edit', [$avaliacionmonitor->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
					                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Estás seguro?')"]); ?>

					                </div>
					                <?php echo Form::close(); ?>

					            </td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	$('#actividades-table').DataTable({
        "iDisplayLength": 100,
        "order": [[ 1, "desc" ]]
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>