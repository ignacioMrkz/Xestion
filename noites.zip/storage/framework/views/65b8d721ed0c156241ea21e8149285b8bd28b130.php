<?php $__env->startSection('content'); ?>
<a href="<?php echo e(url('/coordinador/logout')); ?>"
onclick="event.preventDefault();
document.getElementById('logout-form').submit();">
Logout
</a>

<form id="logout-form" action="<?php echo e(url('/coordinador/logout')); ?>" method="POST" style="display: none;">
	<?php echo e(csrf_field()); ?>

</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>