<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1 class="pull-left">Eventos</h1>
        <h1 class="pull-right">
           <a class="btn btn-primary pull-right" style="margin-top: -10px;margin-bottom: 5px" href="<?php echo route('eventos.create'); ?>">Engadir novo</a>
        </h1>
    </section>
    <div class="content">
        <div class="clearfix"></div>

        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="clearfix"></div>
        <div class="box box-primary">
            <div id='calendar'></div>
            <div class="box-body">
                    <?php echo $__env->make('eventos.table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
        <div class="text-center">
        
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>

      document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');

        var calendar = new FullCalendar.Calendar(calendarEl, {
            plugins: [ 'dayGrid' ],
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,dayGridWeek,dayGridDay'
            },
            displayEventEnd: true,
            events: [
                <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    id: '<?php echo e($evento->id); ?>',
                    title: '<?php echo e(trim($evento->actividade->nome)); ?>',
                    start: '<?php echo e($evento->inicio); ?>',
                    end: '<?php echo e($evento->fin); ?>'
                },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            eventTimeFormat: { // like '14:30:00'
                hour: 'numeric',
                minute: '2-digit',
                meridiem: false,
                hour12: false
            }
        });

        calendar.render();
      });
    $('#eventos-table').DataTable({
        "iDisplayLength": 100
    });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>