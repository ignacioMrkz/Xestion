<table class="table table-responsive" id="avaliacionmonitors-table">
    <thead>
        <tr>
            <th>Participantes</th>
        <th>Primeiravez</th>
        <th>Moza12</th>
        <th>Moza17</th>
        <th>moza26</th>
        <th>Mozo12</th>
        <th>Mozo17</th>
        <th>mozo26</th>
        <th>Valoracionespazo</th>
        <th>Valoracionmateriais</th>
        <th>Valoracionhorario</th>
        <th>Valoracionparticipacion</th>
        <th>Valoracionxeral</th>
        <th>Control</th>
        <th>Obsevacions</th>
        <th>Actividade Id</th>
        <th>Espazo Id</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $avaliacionmonitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avaliacionmonitors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $avaliacionmonitors->participantes; ?></td>
            <td><?php echo $avaliacionmonitors->primeiravez; ?></td>
            <td><?php echo $avaliacionmonitors->moza12; ?></td>
            <td><?php echo $avaliacionmonitors->moza17; ?></td>
            <td><?php echo $avaliacionmonitors->moza26; ?></td>
            <td><?php echo $avaliacionmonitors->mozo12; ?></td>
            <td><?php echo $avaliacionmonitors->mozo17; ?></td>
            <td><?php echo $avaliacionmonitors->mozo26; ?></td>
            <td><?php echo $avaliacionmonitors->valoracionespazo; ?></td>
            <td><?php echo $avaliacionmonitors->valoracionmateriais; ?></td>
            <td><?php echo $avaliacionmonitors->valoracionhorario; ?></td>
            <td><?php echo $avaliacionmonitors->valoracionparticipacion; ?></td>
            <td><?php echo $avaliacionmonitors->valoracionxeral; ?></td>
            <td><?php echo $avaliacionmonitors->control; ?></td>
            <td><?php echo $avaliacionmonitors->obsevacions; ?></td>
            <td><?php echo $avaliacionmonitors->actividade_id; ?></td>
            <td><?php echo $avaliacionmonitors->espazo_id; ?></td>
            <td>
                <?php echo Form::open(['route' => ['avaliacionmonitors.destroy', $avaliacionmonitors->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('avaliacionmonitors.show', [$avaliacionmonitors->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('avaliacionmonitors.edit', [$avaliacionmonitors->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>