<!-- Nome Field -->
<div class="form-group col-sm-12 col-md-4">
    <?php echo Form::label('name', 'Nome:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>

<!-- Nome Field -->
<div class="form-group col-sm-12 col-md-4">
    <?php echo Form::label('apelido1', 'Primeiro apelido:'); ?>

    <?php echo Form::text('apelido1', null, ['class' => 'form-control']); ?>

</div>

<!-- Nome Field -->
<div class="form-group col-sm-12 col-md-4">
    <?php echo Form::label('apelido2', 'Segundo completo:'); ?>

    <?php echo Form::text('apelido2', null, ['class' => 'form-control']); ?>

</div>

<!-- Nome Field -->
<div class="form-group col-sm-12 col-md-6">
    <?php echo Form::label('dni', 'DNI:'); ?>

    <?php echo Form::text('dni', null, ['class' => 'form-control']); ?>

</div>

<!-- Nome Field -->
<div class="form-group col-sm-12 col-md-6">
    <?php echo Form::label('nacemento', 'Data nacemento:'); ?>

    <?php echo Form::date('nacemento', null, ['class' => 'form-control']); ?>

</div>

<!-- Enderezo Field -->
<div class="form-group col-sm-12 col-md-4">
    <?php echo Form::label('email', 'E-mail:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

</div>

<!-- Nome Field -->
<div class="form-group col-sm-12 col-md-4">
    <?php echo Form::label('telefono', 'Teléfono:'); ?>

    <?php echo Form::text('telefono', null, ['class' => 'form-control']); ?>

</div>

<!-- Nome Field -->
<div class="form-group col-sm-12 col-md-4">
    <?php echo Form::label('empresa', 'Empresa:'); ?>

    <?php echo Form::text('empresa', null, ['class' => 'form-control']); ?>

</div>
<?php if(!isset($coordinador)): ?>
<!-- Postal Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('password', 'Contrasinal:'); ?>

    <?php echo Form::password('password', ['class' => 'form-control']); ?>

</div>

<!-- Postal Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('password-confirm', 'Confirma contrasinal:'); ?>

    <?php echo Form::password('password_confirmation', ['class' => 'form-control']); ?>

</div>
<?php endif; ?>
<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('espazos.index'); ?>" class="btn btn-default">Cancel</a>
</div>
