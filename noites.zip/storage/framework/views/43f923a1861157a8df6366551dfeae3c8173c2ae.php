<?php $__env->startSection('content'); ?>
<div class="container">
	<h4>Sorteo participantes</h4>
	<?php if($errors->any()): ?>
	<div class="alert alert-danger">
		<ul>
			<div class="card-panel red white-text darken-2">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($error); ?><br>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</ul>
	</div>
	<?php endif; ?>
	<?php echo Form::open(['url'=>'coordinador/sorteo-participantes']); ?>

	<div class="row">
		<div class="input-field col s12 m6">
			<h5>Total grupos:</h5>
			<p>
				<label>
					<input type="number" name="grupos" value="<?php echo e(old('grupos')); ?>">
				</label>
			</p>
		</div>
		<div class="input-field col s12 m6">
			<h5>Número ganadores:</h5>
			<p>
				<label>
					<input type="number" name="ganadores" value="<?php echo e(old('ganadores')); ?>">
				</label>
			</p>
		</div>
	</div>
	<div class="row">
		<div class="input-field col s12">
			<button class="btn waves-effect waves-light" type="submit">Sorteo
				<i class="material-icons right">send</i>
			</button>
		</div>
	</div>
	<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('select').formSelect();
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>