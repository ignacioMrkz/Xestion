<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1 class="pull-left">Sorteo persoas socias</h1>
        
    </section>
    <div class="content">
        <div class="clearfix"></div>

        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="clearfix"></div>
        <div class="box box-primary">
            <div class="box-body">
                <div class="row">
                    <?php echo Form::open(['url'=>'sorteo']); ?>

                    <div class="form-group col-sm-12 col-md-6 col-lg-3">
                        <?php echo Form::label('azul', 'Nº inscritos Casa Azul:'); ?>

                        <?php echo Form::number('azul', null, ['class' => 'form-control', 'step'=>1, 'min'=>0]); ?>

                    </div>
                    <div class="form-group col-sm-12 col-md-6 col-lg-3">
                        <?php echo Form::label('multiusos', 'Nº inscritos Multiusos:'); ?>

                        <?php echo Form::number('multiusos', null, ['class' => 'form-control', 'step'=>1, 'min'=>0]); ?>

                    </div>
                    <div class="form-group col-sm-12 col-md-6 col-lg-3">
                        <?php echo Form::label('froebel', 'Nº inscritos Froebel:'); ?>

                        <?php echo Form::number('froebel', null, ['class' => 'form-control', 'step'=>1, 'min'=>0]); ?>

                    </div>
                    <div class="form-group col-sm-12 col-md-6 col-lg-3">
                        <?php echo Form::label('luz', 'Nº inscritos Casa da Luz:'); ?>

                        <?php echo Form::number('luz', null, ['class' => 'form-control', 'step'=>1, 'min'=>0]); ?>

                    </div>
                    <div class="form-group col-sm-12 col-md-6 col-lg-3">
                        <?php echo Form::label('ganadores', 'Nº ganadores:'); ?>

                        <?php echo Form::number('ganadores', null, ['class' => 'form-control', 'step'=>1, 'min'=>0]); ?>

                    </div>
                    <div class="form-group col-sm-12">
                        <?php echo Form::submit('Save', ['class' => 'btn btn-primary']); ?>

                        <a href="<?php echo route('socios.index'); ?>" class="btn btn-default">Cancel</a>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
    <div class="number-center">

    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>