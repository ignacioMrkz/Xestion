<?php $__env->startSection('content'); ?>
<?php echo $__env->make('coordinador.layout.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="row">
<table class="highlight centered centered-table">
    <thead>
        <tr>
            <th>Espazo</th>
            <th>Actividade</th>
            <th>Data</th>
            <th>Accions</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $avaliacions->sortBy('espazoNome'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avaliacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($avaliacion->espazoNome); ?></td>
            <td><?php echo e($avaliacion->actividade->nome); ?></td>
            <td><?php echo e($avaliacion->created_at->format('d-m-Y')); ?></td>
            <td>
                <a href="<?php echo url('coordinador/revisar-avaliacion-satisfacion/'.$avaliacion->id); ?>" class="waves-effect waves-light orange btn"><i class="material-icons right">pageview</i>Revisar</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>