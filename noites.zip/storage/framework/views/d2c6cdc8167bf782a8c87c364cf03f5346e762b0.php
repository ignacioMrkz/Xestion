<table class="table table-responsive table-condensed" id="avaliacionmonitors-table">
    <thead>
        <tr>
            <th>Participantes</th>
        <th>Actividade</th>
        <th>Data</th>
        <th>Espazo</th>
        <th>Revisada</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $avaliacionmonitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $avaliacionmonitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $avaliacionmonitor->participantes; ?></td>
            <td><?php echo $avaliacionmonitor->actividade->nome; ?></td>
            <td><?php echo date_format($avaliacionmonitor->data, 'd-m-Y'); ?></td>
            <td><?php echo $avaliacionmonitor->espazo->nome; ?></td>
            <td>
                <a href="<?php echo url('cambiar-revisada/'.$avaliacionmonitor->id); ?>">
                <?php if($avaliacionmonitor->revisada): ?>
                <i class="text-green glyphicon glyphicon glyphicon-ok"></i>
                <?php else: ?>
                <i class="text-red glyphicon glyphicon-remove"></i>
                <?php endif; ?>
                </a>
            </td>
            <td>
                <?php echo Form::open(['route' => ['avaliacionmonitors.destroy', $avaliacionmonitor->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('avaliacionmonitors.show', [$avaliacionmonitor->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('avaliacionmonitors.edit', [$avaliacionmonitor->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Estás seguro?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $('#avaliacionmonitors-table').DataTable();
</script>
<?php $__env->stopSection(); ?>