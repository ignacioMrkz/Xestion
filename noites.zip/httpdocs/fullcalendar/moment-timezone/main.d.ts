declare module "@fullcalendar/moment-timezone" {
    import "@fullcalendar/moment-timezone/builds/moment-timezone-with-data";
    const _default_12: import("@fullcalendar/core/plugin-system").PluginDef;
    export default _default_12;
}