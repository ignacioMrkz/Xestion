declare module "@fullcalendar/rrule" {
    const _default_13: import("@fullcalendar/core/plugin-system").PluginDef;
    export default _default_13;
}