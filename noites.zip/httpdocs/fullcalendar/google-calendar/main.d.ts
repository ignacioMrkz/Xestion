declare module "@fullcalendar/google-calendar" {
    const _default_7: import("@fullcalendar/core/plugin-system").PluginDef;
    export default _default_7;
}